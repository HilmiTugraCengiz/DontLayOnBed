start.bat uygulamasına tıkladığınızda öğrenci no'lu portta otomatik olarak yayına başlar.

admin paneline giriş yapmak için admin hesabı:
	
	e-mail: admin@localhost.com
	şifre : admin

giriş yaptıktan sonra "/admin" yazmanız yeterlidir.

Uygulamanın Veri Tabanı bağlantısı için cihazda MSSQL Server kurulu olması gerekmektedir.

MSSQL Server:
	MSSQLLOCALDB sunucusu DontLayOnBed veri tabanı kullanılır
	Veri Tabanı otomatik eklenir ve güncellenir